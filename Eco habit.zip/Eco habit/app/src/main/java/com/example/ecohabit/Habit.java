package com.example.ecohabit;

public class Habit {
    private long id;
    private String name;
    private String category;
    private String frequency;
    private int points; // points per completion

    public Habit(long id, String name, String category, String frequency, int points) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.frequency = frequency;
        this.points = points;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public String getFrequency() { return frequency; }
    public int getPoints() { return points; }
}
