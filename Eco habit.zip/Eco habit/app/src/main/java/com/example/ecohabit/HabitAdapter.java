package com.example.ecohabit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HabitAdapter extends RecyclerView.Adapter<HabitAdapter.HabitVH> {
    public interface OnToggleListener {
        void onToggle(Habit habit, boolean checked);
    }

    private Context ctx;
    private ArrayList<Habit> items;
    private DBHelper db;
    private OnToggleListener listener;

    public HabitAdapter(Context ctx, ArrayList<Habit> items, DBHelper db, OnToggleListener listener) {
        this.ctx = ctx;
        this.items = items;
        this.db = db;
        this.listener = listener;
    }

    @Override
    public HabitVH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(ctx).inflate(R.layout.item_habit, parent, false);
        return new HabitVH(v);
    }

    @Override
    public void onBindViewHolder(HabitVH holder, int position) {
        Habit h = items.get(position);
        holder.name.setText(h.getName());
        holder.cat.setText(h.getCategory() + " • " + h.getFrequency());
        boolean done = db.isCompletedToday(h.getId());
        holder.check.setChecked(done);
        holder.points.setText("+" + h.getPoints());
        holder.check.setOnCheckedChangeListener((btn, checked) -> {
            // notify parent to handle DB ops
            if (listener != null) listener.onToggle(h, checked);
            // update immediately UI is already set by checkbox state
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class HabitVH extends RecyclerView.ViewHolder {
        TextView name, cat, points;
        CheckBox check;
        HabitVH(View v) {
            super(v);
            name = v.findViewById(R.id.habitName);
            cat = v.findViewById(R.id.habitCat);
            points = v.findViewById(R.id.habitPoints);
            check = v.findViewById(R.id.habitCheck);
        }
    }
}
