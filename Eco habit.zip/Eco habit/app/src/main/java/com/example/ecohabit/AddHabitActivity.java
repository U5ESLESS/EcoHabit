package com.example.ecohabit;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AddHabitActivity extends AppCompatActivity {
    EditText etName;
    Spinner spCategory, spFreq;
    EditText etPoints;
    DBHelper db;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_habit);
        db = new DBHelper(this);
        etName = findViewById(R.id.etName);
        spCategory = findViewById(R.id.spCategory);
        spFreq = findViewById(R.id.spFreq);
        etPoints = findViewById(R.id.etPoints);
        Button btnSave = findViewById(R.id.btnSave);

        // simple spinner items (can be adjusted)
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[] {"Hemat Energi", "Ramah Lingkungan", "Aktivitas Sehat"});
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(catAdapter);

        ArrayAdapter<String> freqAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[] {"Harian", "Mingguan"});
        freqAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFreq.setAdapter(freqAdapter);

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String cat = spCategory.getSelectedItem().toString();
            String freq = spFreq.getSelectedItem().toString();
            int points = 10;
            try { points = Integer.parseInt(etPoints.getText().toString().trim()); } catch (Exception ignored) {}

            if (name.isEmpty()) {
                Toast.makeText(this, "Isi nama kebiasaan", Toast.LENGTH_SHORT).show();
                return;
            }
            db.addHabit(name, cat, freq, points);
            Toast.makeText(this, "Kebiasaan tersimpan", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
