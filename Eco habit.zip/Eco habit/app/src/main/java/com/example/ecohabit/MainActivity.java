package com.example.ecohabit;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    DBHelper db;
    RecyclerView rv;
    HabitAdapter adapter;
    TextView txtGreeting, txtEcoPoints;
    ArrayList<Habit> habits;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DBHelper(this);

        txtGreeting = findViewById(R.id.greeting);
        txtEcoPoints = findViewById(R.id.ecoPoints);
        rv = findViewById(R.id.rvHabits);
        FloatingActionButton fab = findViewById(R.id.fabAdd);
        findViewById(R.id.btnProgress).setOnClickListener(v -> startActivity(new Intent(this, ProgressActivity.class)));

        rv.setLayoutManager(new LinearLayoutManager(this));
        loadHabits();

        fab.setOnClickListener(v -> startActivity(new Intent(this, AddHabitActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHabits();
    }

    private void loadHabits() {
        habits = db.getAllHabits();
        adapter = new HabitAdapter(this, habits, db, (habit, checked) -> {
            if (checked) db.addCompletionToday(habit.getId());
            else db.removeCompletionToday(habit.getId());
            updatePoints();
        });
        rv.setAdapter(adapter);
        updatePoints();
        String todayStr = new SimpleDateFormat("EEEE, dd MMM", Locale.getDefault()).format(Calendar.getInstance().getTime());
        txtGreeting.setText("Halo, Randist 👋 — " + todayStr);
    }

    private void updatePoints() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Calendar.getInstance().getTime());
        int p = db.ecoPointsOn(today);
        txtEcoPoints.setText(p + " Eco Points hari ini");
    }
}
