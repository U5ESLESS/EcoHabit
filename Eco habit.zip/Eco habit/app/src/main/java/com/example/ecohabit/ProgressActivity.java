package com.example.ecohabit;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ProgressActivity extends AppCompatActivity {
    DBHelper db;
    LinearLayout barsContainer;
    TextView txtTotal;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);
        db = new DBHelper(this);
        barsContainer = findViewById(R.id.barsContainer);
        txtTotal = findViewById(R.id.txtTotalPoints);

        if (barsContainer != null && txtTotal != null) {
            drawWeekly();
        }
    }

    private void drawWeekly() {
        barsContainer.removeAllViews();
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat labelFmt = new SimpleDateFormat("EEE", Locale.getDefault());
        int total = 0;

        // gather 7 days from 6 days ago -> today
        for (int i = 6; i >= 0; i--) {
            Calendar c = (Calendar) cal.clone();
            c.add(Calendar.DAY_OF_YEAR, -i);
            String date = sdf.format(c.getTime());
            int pts = db.ecoPointsOn(date);
            total += pts;

            // create a vertical bar (simple)
            LinearLayout container = new LinearLayout(this);
            container.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams contParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
            contParams.setMargins(8, 0, 8, 0);
            container.setLayoutParams(contParams);

            TextView tvTop = new TextView(this);
            tvTop.setText(String.valueOf(pts));
            tvTop.setTextAlignment(TextView.TEXT_ALIGNMENT_CENTER);

            View bar = new View(this);
            int height = Math.min(200, pts * 8 + 10); // scale
            LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
            barParams.setMargins(0, 8, 0, 8);
            bar.setLayoutParams(barParams);
            bar.setBackgroundResource(R.drawable.bar_bg); // create drawable

            TextView tvLabel = new TextView(this);
            tvLabel.setText(labelFmt.format(c.getTime()));
            tvLabel.setTextAlignment(TextView.TEXT_ALIGNMENT_CENTER);

            container.addView(tvTop);
            container.addView(bar);
            container.addView(tvLabel);
            barsContainer.addView(container);
        }
        txtTotal.setText(total + " Eco Points minggu ini");
    }
}
