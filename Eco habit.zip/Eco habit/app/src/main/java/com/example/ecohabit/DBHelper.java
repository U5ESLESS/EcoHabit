package com.example.ecohabit;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "ecohabit.db";
    private static final int DB_VER = 1;

    // tables
    private static final String T_HABIT = "habits";
    private static final String T_COMPLETION = "completions";

    public DBHelper(Context c) {
        super(c, DB_NAME, null, DB_VER);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createHabit = "CREATE TABLE " + T_HABIT + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "category TEXT," +
                "frequency TEXT," +
                "points INTEGER DEFAULT 10" +
                ")";
        String createCompletion = "CREATE TABLE " + T_COMPLETION + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "habit_id INTEGER," +
                "date TEXT," +
                "FOREIGN KEY(habit_id) REFERENCES " + T_HABIT + "(id)" +
                ")";
        db.execSQL(createHabit);
        db.execSQL(createCompletion);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + T_COMPLETION);
        db.execSQL("DROP TABLE IF EXISTS " + T_HABIT);
        onCreate(db);
    }

    // CRUD habits
    public long addHabit(String name, String category, String freq, int points) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("category", category);
        v.put("frequency", freq);
        v.put("points", points);
        return db.insert(T_HABIT, null, v);
    }

    public ArrayList<Habit> getAllHabits() {
        ArrayList<Habit> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, name, category, frequency, points FROM " + T_HABIT + " ORDER BY id DESC", null);
        while (c.moveToNext()) {
            list.add(new Habit(
                    c.getLong(0),
                    c.getString(1),
                    c.getString(2),
                    c.getString(3),
                    c.getInt(4)
            ));
        }
        c.close();
        return list;
    }

    // completions
    private String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    public boolean isCompletedToday(long habitId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM " + T_COMPLETION + " WHERE habit_id=? AND date=?", new String[]{String.valueOf(habitId), today()});
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    public long addCompletionToday(long habitId) {
        if (isCompletedToday(habitId)) return -1;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("habit_id", habitId);
        v.put("date", today());
        return db.insert(T_COMPLETION, null, v);
    }

    public int removeCompletionToday(long habitId) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(T_COMPLETION, "habit_id=? AND date=?", new String[]{String.valueOf(habitId), today()});
    }

    // compute eco points for a date range (date strings yyyy-MM-dd)
    public int ecoPointsBetween(String startDate, String endDate) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT SUM(h.points) FROM " + T_COMPLETION + " c JOIN " + T_HABIT + " h ON c.habit_id = h.id WHERE date BETWEEN ? AND ?";
        Cursor c = db.rawQuery(sql, new String[]{startDate, endDate});
        int total = 0;
        if (c.moveToFirst()) {
            total = c.isNull(0) ? 0 : c.getInt(0);
        }
        c.close();
        return total;
    }

    // helper: points for today (single date)
    public int ecoPointsOn(String date) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT SUM(h.points) FROM " + T_COMPLETION + " c JOIN " + T_HABIT + " h ON c.habit_id = h.id WHERE date = ?";
        Cursor c = db.rawQuery(sql, new String[]{date});
        int total = 0;
        if (c.moveToFirst()) {
            total = c.isNull(0) ? 0 : c.getInt(0);
        }
        c.close();
        return total;
    }
}
